# Upstream provenance

- Readest repository: https://github.com/readest/readest
- Readest commit: `8d76d3fc1f0e26f8c5dbe1fc343f9d69256eefc2`
- Version inspected: 0.12.10
- License: AGPL-3.0-or-later (root LICENSE, public/LICENSE.txt).
- Actual rendering engine: https://github.com/readest/foliate-js
- Pinned submodule commit used by that Readest checkout: `341dc63cda7ad26b31ada4ee905e40b5020da88a`
- Engine vendored into `public/vendor/foliate/`; original MIT LICENSE retained. Its vendor ZIP/fflate headers retain their notices. Browser is not fetching a moving CDN version.
- `public/vendor/readest/rtl.js` adapts Readest's `apps/readest-app/src/utils/rtl.ts`, removing TypeScript annotations and app-specific UI-language dependency. Direction logic retained.

This is a focused derivative using Readest's actual reader engine and adapted RTL utility; it is not a full fork of Readest's React/Tauri application. The outer single-book shell, source adapter, Arabic normalized search, deployment scripts and admin documentation are new. Library/auth/import/sync routes are not shipped. Upstream upgrades should be reviewed and regression-tested rather than fetched automatically.

Local engine modifications:
1. `fixed-layout.js`: remove the bare import of construct-style-sheets-polyfill. Modern native constructable stylesheets are required (current Chrome/Edge/Firefox/Safari). No PDF/mobi support is exposed by the UI.
2. No upstream paginator/search algorithms were rewritten. The app performs bounded chapter-wise normalized search with original DOM offsets for CFI navigation.

Runtime content transformation removes scripts, active embeds/forms and event handlers; adds a restrictive document CSP to EPUB XHTML. This is applied by the single-book shell, not a vendored engine patch. Source archives omit the EPUB because its licensing is independent, and include a script to generate an original test book.
