# Optional backend publishing contract

The delivered app is fully static; no upload endpoint, admin login, database or secret exists. Reader visitors stay anonymous. A future upload page must be restricted to the administrator (company SSO, reverse-proxy access restriction, or equivalent); a public unauthenticated write endpoint would let anyone replace the book. This administrative restriction does not add reader login.

The separation point is `src/book-source.js`. Keep the UI and rendering engine unchanged. A future service can implement:

- GET /api/current-book → {revision, source, bytes, publishedAt}; no-store. Source is a same-origin immutable `/books/<sha256>.epub` URL.
- POST /api/books → authorized multipart upload, size limits, streaming to temporary storage, EPUB validation, checksum, staged preview. No writes to current publication until validation succeeds.
- POST /api/books/:revision/publish → atomic pointer replacement to a fully uploaded, validated version.
- Optional rollback → select a prior immutable revision; preserve the revision-specific position/bookmark namespaces.

Do not trust the filename or MIME supplied by the uploader. Validate ZIP central directory, mimetype, container.xml, OPF/spine and resources; limit total uncompressed bytes and compression ratio; reject encrypted/DRM books and traversal names. Store outside executable directories. Enforce authorization/CSRF protection at the server. The source adapter must enforce same-origin resources and use a stable publisher revision plus checksum validation as needed.

For genuinely huge books, add HTTP Range support and use the ZIP engine's range reader with immutable URLs, or unpack validated EPUB resources into an immutable version directory and provide a resource loader. That avoids the current full compressed-file download. Use a background worker or server-side prebuilt search index for exceptionally large single chapters. These are documented extension points, not features claimed to be implemented.
