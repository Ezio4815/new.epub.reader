import { sha256 } from '@noble/hashes/sha256';
// Replace this adapter with GET /api/current-book on a backend deployment.
// The public reader never imports user files and never sends local reading state.
export async function freshJSON(path) {
  const url = new URL(path, document.baseURI);
  url.searchParams.set('_fresh', `${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const response = await fetch(url, {cache:'no-store'});
  if (!response.ok) throw new Error(`تعذّر الوصول إلى إعدادات الكتاب (${response.status}).`);
  return response.json();
}
export async function loadEdition(onProgress) {
  const config = await freshJSON('./book.json');
  const url = new URL(config.source || './books/current.epub', document.baseURI);
  if (url.origin !== location.origin) throw new Error('يجب استضافة الكتاب على نفس نطاق القارئ.');
  url.searchParams.set('_fresh', `${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const response = await fetch(url, {cache:'no-store'});
  if (!response.ok) throw new Error(`ملف الكتاب غير متاح (${response.status}). يرجى التواصل مع مسؤول الموقع.`);
  const total = Number(response.headers.get('content-length'));
  const reader = response.body?.getReader();
  let blob;
  if (reader) {
    const chunks=[]; let received=0;
    while (true) {
      const {done,value}=await reader.read(); if(done) break;
      chunks.push(value); received+=value.length;
      onProgress(received,total);
    }
    blob=new Blob(chunks,{type:'application/epub+zip'});
  } else blob=await response.blob();
  const magic=new Uint8Array(await blob.slice(0,4).arrayBuffer());
  if(magic[0]!==0x50 || magic[1]!==0x4b) throw new Error('الملف المنشور ليس كتاب EPUB صالحًا.');
  // Hash actual bytes: replacing only current.epub still changes the edition key.
  const hasher=sha256.create();
  for(let offset=0;offset<blob.size;offset+=4*1024*1024){
    hasher.update(new Uint8Array(await blob.slice(offset,offset+4*1024*1024).arrayBuffer()));
    await new Promise(resolve=>setTimeout(resolve,0));
  }
  const hash=hasher.digest();
  const revision=[...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
  return {config,revision,file:new File([blob],'current.epub',{type:'application/epub+zip'})};
}
