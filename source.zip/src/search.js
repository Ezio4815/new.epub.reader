// One chapter at a time; normalized offsets retain the original DOM range.
export const fold = s => s.normalize('NFKD').replace(/[\u0640\u064b-\u065f\u0670\u06d6-\u06ed\u0300-\u036f]/g,'').replace(/[أإآٱ]/g,'ا').toLowerCase();
const pause=()=>new Promise(resolve=>setTimeout(resolve,0));
export async function* searchBook(book, query, signal) {
  const needle=fold(query.trim()).replace(/\s+/g,' ');
  if(!needle || needle.length<2) return;
  for(let index=0;index<book.sections.length;index++) {
    if(signal.aborted) return;
    const section=book.sections[index];
    if(!section.createDocument) continue;
    const doc=await section.createDocument();
    const nodes=[]; let text=''; const offsets=[];
    const walker=doc.createTreeWalker(doc.body || doc.documentElement,NodeFilter.SHOW_TEXT,{acceptNode(node){return node.parentElement?.closest('script,style,noscript')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT;}});
    let node, ticks=0;
    while((node=walker.nextNode())) {
      const n=nodes.push(node)-1;
      for(let i=0;i<node.length;i++) {
        const normalized=fold(node.data[i]);
        for(const char of normalized) {
          const c=/\s/.test(char)?' ':char;
          if(c===' ' && text.endsWith(' ')) continue;
          text+=c; offsets.push([n,i]);
        }
      }
      if(++ticks%150===0){await pause();if(signal.aborted)return;}
    }
    let from=0, found=0;
    while((from=text.indexOf(needle,from))!==-1) {
      if(signal.aborted)return;
      const start=offsets[from],end=offsets[from+needle.length-1];
      const range=doc.createRange();
      range.setStart(nodes[start[0]],start[1]);range.setEnd(nodes[end[0]],end[1]+1);
      yield {index,range,excerpt:text.slice(Math.max(0,from-45),Math.min(text.length,from+needle.length+75))};
      from+=needle.length;
      if(++found%20===0){await pause();if(signal.aborted)return;}
    }
    yield {progress:(index+1)/book.sections.length};
    await pause();
  }
}
