import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fold} from '../src/search.js';
import {loadEdition} from '../src/book-source.js';
import {getDirFromLanguage} from '../public/vendor/readest/rtl.js';
test('Arabic search ignores tashkil, tatweel and alef variants; mixed Latin remains searchable',()=>{assert.equal(fold('إِنَّ الْقِرَاءَةَ'),'ان القراءة');assert.equal(fold('آفاق أفق إبداع ٱسم'),'افاق افق ابداع اسم');assert.equal(fold('كــتاب EPUB'),'كتاب epub');assert.equal(fold('كتاب 2026'),'كتاب 2026')});
test('Readest language direction handles regional tags',()=>{assert.equal(getDirFromLanguage('ar-EG'),'rtl');assert.equal(getDirFromLanguage('en'),'auto')});
test('fixed-file replacement changes edition and always bypasses browser cache',async()=>{
 const originalFetch=globalThis.fetch;globalThis.document={baseURI:'https://example.org/project/'};globalThis.location={origin:'https://example.org'};
 let bytes=Buffer.from('PK\x03\x04edition-one');const calls=[];
 globalThis.fetch=async(url,options)=>{calls.push([String(url),options]);return String(url).includes('book.json')?new Response(JSON.stringify({source:'./books/current.epub'})):new Response(bytes,{headers:{'content-length':String(bytes.length)}})};
 try{const a=await loadEdition(()=>{});assert.equal(a.revision,createHash('sha256').update(bytes).digest('hex'));assert.equal((await loadEdition(()=>{})).revision,a.revision);bytes=Buffer.from('PK\x03\x04edition-two');assert.notEqual((await loadEdition(()=>{})).revision,a.revision);assert.ok(calls.every(([url,o])=>url.includes('/project/')&&url.includes('_fresh=')&&o.cache==='no-store'));globalThis.fetch=async()=>new Response(JSON.stringify({source:'https://other.example/book.epub'}));await assert.rejects(loadEdition(()=>{}),/نفس نطاق/);}finally{globalThis.fetch=originalFetch;delete globalThis.document;delete globalThis.location}
});
