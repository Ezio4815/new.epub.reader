import {execFileSync} from 'node:child_process';
import {build} from 'vite';
execFileSync(process.execPath,['scripts/publish-book.mjs'],{stdio:'inherit'});
await build();
// Source offer included in each deployment; original EPUB not included in the
// source bundle because the book's publishing rights are separate from code.
execFileSync('python3',['scripts/source-archive.py','dist/source.zip'],{stdio:'inherit'});
