"""Generate original Arabic EPUB test content, not a Hindawi publication.
Default: 12 chapters. --stress: 2,000 labelled content units, 100 chapters,
~600,000 Arabic words, 100 distinct PNGs and 100 tables. Screen pages vary.
"""
import argparse, zipfile, html, pathlib, random, struct, zlib
p=argparse.ArgumentParser(); p.add_argument('--stress',action='store_true');p.add_argument('--output',default='public/books/current.epub');args=p.parse_args()
chapters=100 if args.stress else 12
units=20 if args.stress else 2
out=pathlib.Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
titles=['مساحة للقراءة','اللغة والاتجاه','رحلة بين السطور','الصور في الكتاب','الجداول والمعلومات','القراءة على الهاتف','فصل جديد','الذاكرة والمعرفة','وقت للتأمل','المعنى والسياق','العودة إلى الكتاب','نهاية التجربة']
text='تفتح القراءة أمام الإنسان أبواب المعرفة، وتمنحه فرصة للتأمل في العالم من حوله. نقرأ لنسأل ونفهم ونكتشف، ونعود إلى الكتاب فنجد في صفحاته معنى جديدًا. يمتد النص العربي من اليمين إلى اليسار، وتجاوره أحيانًا كلمات مثل EPUB وReadest وأرقام مثل 2026 دون أن يختل سياق العبارة. يختار القارئ حجم الخط الذي يناسبه، وينتقل بين الفصول وفق إيقاعه الخاص. '
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('mimetype','application/epub+zip',compress_type=zipfile.ZIP_STORED)
 z.writestr('META-INF/container.xml','<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="EPUB/book.opf" media-type="application/oebps-package+xml"/></rootfiles></container>')
 manifest='<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>'; spine=''; toc=''
 for i in range(chapters):
  title=(f'الفصل {i+1}' if args.stress else titles[i]); body=f'<h1>{title}</h1>'
  if i==0:body+='<p>هذا كتاب تجريبي أصلي لاختبار القارئ، وليس إصدارًا من مؤسسة هنداوي. يمكن استبداله بكتابك بصيغة EPUB.</p>'
  for u in range(units):body+=f'<h2>المقطع {i*units+u+1}</h2>'+''.join(f'<p>{text}</p>' for _ in range(5))
  body+='<p>اختبار البحث بالتشكيل: إِنَّ الْقِرَاءَةَ مَعْرِفَةٌ. كلمة اختبار فريدة: زمردة'+str(i+1)+'</p>'
  # Deterministic real PNG test raster; chart-like color blocks, no generated art.
  rng=random.Random(i); w,h=640,360
  raw=b''.join(b'\0'+bytes(rng.randrange(64,220) for _ in range(w*3)) for y in range(h))
  def chunk(t,d):return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
  png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')
  z.writestr(f'EPUB/image{i}.png',png)
  body+=f'<figure><img src="image{i}.png" alt="صورة اختبار ألوان للفصل {i+1}"/><figcaption>صورة تجريبية لاختبار تحميل الصور.</figcaption></figure><table><caption>جدول عربي تجريبي</caption><thead><tr><th>البند</th><th>القيمة</th><th>الوحدة</th><th>ملاحظات</th></tr></thead><tbody>'+''.join(f'<tr><td>السجل {r}</td><td>{r*17}</td><td>kg</td><td>بيانات باللغة العربية</td></tr>' for r in range(1,12))+'</tbody></table>'
  if i==chapters-1:body+='<p>وصلت إلى نهاية الكتاب التجريبي. علامة النهاية: ياقوتةالنهاية.</p>'
  z.writestr(f'EPUB/c{i}.xhtml',f'<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" lang="ar" dir="rtl"><head><title>{title}</title><style>body{{font-family:serif}}table{{border-collapse:collapse;width:100%}}th,td{{border:1px solid #888;padding:8px}}img{{max-width:100%}}h1{{font-size:1.6em}}p{{text-align:justify}}</style></head><body>{body}</body></html>')
  manifest+=f'<item id="c{i}" href="c{i}.xhtml" media-type="application/xhtml+xml"/><item id="im{i}" href="image{i}.png" media-type="image/png"/>';spine+=f'<itemref idref="c{i}"/>';toc+=f'<li><a href="c{i}.xhtml">{title}</a></li>'
 z.writestr('EPUB/nav.xhtml',f'<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" dir="rtl"><head><title>الفهرس</title></head><body><nav epub:type="toc"><ol>{toc}</ol></nav></body></html>')
 z.writestr('EPUB/book.opf',f'<?xml version="1.0"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="uid">original-arabic-test-{chapters}</dc:identifier><dc:title>{"اختبار الكتاب الكبير" if args.stress else "رحلة القراءة — كتاب تجريبي"}</dc:title><dc:language>ar</dc:language><dc:creator>نص تجريبي لاختبار القارئ</dc:creator><meta property="dcterms:modified">2026-09-27T00:00:00Z</meta></metadata><manifest>{manifest}</manifest><spine page-progression-direction="rtl">{spine}</spine></package>')
print(f'{out}: {out.stat().st_size/1048576:.1f} MiB, {chapters} chapters, {chapters*units} content units')
