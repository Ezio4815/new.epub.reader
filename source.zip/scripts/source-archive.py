import pathlib,sys,zipfile
root=pathlib.Path('.');output=pathlib.Path(sys.argv[1]);output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
 for p in root.rglob('*'):
  if not p.is_file() or any(x in p.parts for x in ['node_modules','dist','.git','.sites-runtime','.openai','artifacts']):continue
  if p.suffix in ['.epub','.zip','.png']:continue
  z.write(p,p.as_posix())
print(output)
