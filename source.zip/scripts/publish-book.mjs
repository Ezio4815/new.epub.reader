import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root=process.argv[2]||'public';
const book=await readFile(`${root}/books/current.epub`);
if(book[0]!==0x50||book[1]!==0x4b)throw Error('current.epub is not a ZIP/EPUB');
await writeFile(`${root}/books/revision.json`,JSON.stringify({sha256:createHash('sha256').update(book).digest('hex'),bytes:book.length,publishedAt:new Date().toISOString()},null,2));
console.log('Book revision published.');
